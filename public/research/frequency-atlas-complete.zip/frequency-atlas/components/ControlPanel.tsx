// components/ControlPanel.tsx
'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Info, TrendingUp, Clock, DollarSign, CheckCircle2, AlertCircle } from 'lucide-react';
import { INTERVENTIONS, FREQUENCY_BANDS, type Intervention } from '../data/interventions';

interface ControlPanelProps {
  selectedIntervention: Intervention | null;
  onSelectIntervention: (intervention: Intervention) => void;
}

const CATEGORIES = [
  { id: 'all', label: 'All', icon: '🧠' },
  { id: 'meditation', label: 'Meditation', icon: '🧘' },
  { id: 'sound', label: 'Sound', icon: '🎵' },
  { id: 'electromagnetic', label: 'Electromagnetic', icon: '⚡' },
  { id: 'neuromodulation', label: 'Neuromodulation', icon: '🔬' },
  { id: 'pharmacological', label: 'Pharmacological', icon: '💊' },
  { id: 'physiological', label: 'Physiological', icon: '❤️' }
];

const EVIDENCE_LABELS = {
  gold: { label: 'Gold Standard', color: 'text-yellow-400', icon: '🥇', desc: 'RCTs, replicated' },
  silver: { label: 'Strong Evidence', color: 'text-gray-300', icon: '🥈', desc: 'Controlled trials' },
  bronze: { label: 'Emerging', color: 'text-amber-600', icon: '🥉', desc: 'Preliminary research' },
  preliminary: { label: 'Preliminary', color: 'text-gray-500', icon: '📊', desc: 'Early studies' }
};

const SAFETY_LABELS = {
  excellent: { label: 'Excellent', color: 'bg-green-500', desc: 'Minimal risk' },
  good: { label: 'Good', color: 'bg-blue-500', desc: 'Low risk' },
  moderate: { label: 'Moderate', color: 'bg-yellow-500', desc: 'Requires monitoring' },
  'requires-supervision': { label: 'Supervised', color: 'bg-orange-500', desc: 'Clinical supervision required' }
};

export default function ControlPanel({ selectedIntervention, onSelectIntervention }: ControlPanelProps) {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showDetails, setShowDetails] = useState(false);

  const filteredInterventions = INTERVENTIONS.filter(intervention => {
    const matchesCategory = selectedCategory === 'all' || intervention.category === selectedCategory;
    const matchesSearch = intervention.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         intervention.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex flex-col h-full bg-gray-900 text-white">
      {/* Header */}
      <div className="p-6 border-b border-gray-800">
        <h2 className="text-2xl font-bold mb-2">Select Intervention</h2>
        <p className="text-gray-400 text-sm">Choose a consciousness modulation technique to visualize</p>
        
        {/* Search */}
        <div className="mt-4 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search interventions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:border-blue-500 text-sm"
          />
        </div>
        
        {/* Category filters */}
        <div className="mt-4 flex gap-2 flex-wrap">
          {CATEGORIES.map(category => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                selectedCategory === category.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              }`}
            >
              <span className="mr-1">{category.icon}</span>
              {category.label}
            </button>
          ))}
        </div>
      </div>

      {/* Intervention list */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {filteredInterventions.map(intervention => (
          <motion.button
            key={intervention.id}
            onClick={() => {
              onSelectIntervention(intervention);
              setShowDetails(true);
            }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`w-full text-left p-4 rounded-xl transition-all border-2 ${
              selectedIntervention?.id === intervention.id
                ? 'bg-blue-600/20 border-blue-500 shadow-lg shadow-blue-500/20'
                : 'bg-gray-800 border-gray-700 hover:border-gray-600 hover:bg-gray-750'
            }`}
          >
            <div className="flex items-start justify-between mb-2">
              <h3 className="font-semibold text-base">{intervention.name}</h3>
              <div className="flex items-center gap-1">
                <span className={`text-xs ${EVIDENCE_LABELS[intervention.evidence.quality].color}`}>
                  {EVIDENCE_LABELS[intervention.evidence.quality].icon}
                </span>
              </div>
            </div>
            
            <p className="text-gray-400 text-xs mb-3 line-clamp-2">
              {intervention.description}
            </p>
            
            {/* Frequency bands affected */}
            <div className="flex flex-wrap gap-1.5 mb-2">
              {intervention.frequencyEffects.map((effect, idx) => (
                <div
                  key={idx}
                  className="px-2 py-0.5 rounded text-xs font-medium flex items-center gap-1"
                  style={{
                    backgroundColor: FREQUENCY_BANDS[effect.band].color + '33',
                    color: FREQUENCY_BANDS[effect.band].color
                  }}
                >
                  <span className="capitalize">{effect.band}</span>
                  {effect.change === 'increase' && <TrendingUp className="w-3 h-3" />}
                  {effect.change === 'decrease' && <TrendingUp className="w-3 h-3 rotate-180" />}
                </div>
              ))}
            </div>
            
            {/* Quick stats */}
            <div className="flex items-center gap-3 text-xs text-gray-500">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {intervention.timeInvestment}
              </span>
              <span className="flex items-center gap-1">
                <DollarSign className="w-3 h-3" />
                {intervention.cost}
              </span>
              <span className={`px-2 py-0.5 rounded ${SAFETY_LABELS[intervention.safety].color} text-white`}>
                {SAFETY_LABELS[intervention.safety].label}
              </span>
            </div>
          </motion.button>
        ))}
        
        {filteredInterventions.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <Info className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No interventions found matching your criteria</p>
          </div>
        )}
      </div>

      {/* Detailed info panel */}
      <AnimatePresence>
        {showDetails && selectedIntervention && (
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="absolute inset-0 bg-gray-900 z-50 overflow-y-auto"
          >
            <div className="p-6">
              {/* Header with close button */}
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-2xl font-bold mb-1">{selectedIntervention.name}</h2>
                  <div className="flex items-center gap-2 text-sm">
                    <span className={`${EVIDENCE_LABELS[selectedIntervention.evidence.quality].color}`}>
                      {EVIDENCE_LABELS[selectedIntervention.evidence.quality].icon} {EVIDENCE_LABELS[selectedIntervention.evidence.quality].label}
                    </span>
                    <span className="text-gray-500">•</span>
                    <span className="text-gray-400">
                      {selectedIntervention.evidence.studyCount} studies, {selectedIntervention.evidence.participants} participants
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setShowDetails(false)}
                  className="text-gray-400 hover:text-white p-2"
                >
                  ✕
                </button>
              </div>

              {/* Description */}
              <div className="mb-6">
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <Info className="w-4 h-4" />
                  Description
                </h3>
                <p className="text-gray-300 text-sm">{selectedIntervention.description}</p>
              </div>

              {/* Mechanism */}
              <div className="mb-6">
                <h3 className="font-semibold mb-2">Mechanism of Action</h3>
                <p className="text-gray-300 text-sm">{selectedIntervention.mechanism}</p>
              </div>

              {/* Frequency Effects */}
              <div className="mb-6">
                <h3 className="font-semibold mb-3">Brainwave Effects</h3>
                <div className="space-y-2">
                  {selectedIntervention.frequencyEffects.map((effect, idx) => (
                    <div key={idx} className="bg-gray-800 rounded-lg p-3">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <div
                            className="w-3 h-3 rounded"
                            style={{ backgroundColor: FREQUENCY_BANDS[effect.band].color }}
                          />
                          <span className="font-medium capitalize">{effect.band}</span>
                          <span className="text-gray-400 text-xs">
                            {FREQUENCY_BANDS[effect.band].range}
                          </span>
                        </div>
                        <span className={`text-xs px-2 py-0.5 rounded ${
                          effect.change === 'increase' ? 'bg-green-600' :
                          effect.change === 'decrease' ? 'bg-red-600' :
                          'bg-blue-600'
                        }`}>
                          {effect.change}
                        </span>
                      </div>
                      <p className="text-gray-400 text-xs">
                        {FREQUENCY_BANDS[effect.band].description}
                      </p>
                      {effect.region && (
                        <p className="text-gray-500 text-xs mt-1">
                          Region: {effect.region}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Clinical Outcomes */}
              <div className="mb-6">
                <h3 className="font-semibold mb-3">Clinical Applications</h3>
                <div className="space-y-2">
                  {selectedIntervention.clinicalOutcomes.map((outcome, idx) => (
                    <div key={idx} className="bg-gray-800 rounded-lg p-3">
                      <div className="flex items-start justify-between mb-2">
                        <span className="font-medium">{outcome.condition}</span>
                        <span className={`text-xs px-2 py-0.5 rounded ${
                          outcome.effectiveness === 'high' ? 'bg-green-600' :
                          outcome.effectiveness === 'moderate' ? 'bg-yellow-600' :
                          outcome.effectiveness === 'low' ? 'bg-gray-600' :
                          'bg-blue-600'
                        }`}>
                          {outcome.effectiveness}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs text-gray-400">
                        <div>
                          <span className="text-gray-500">Time to effect:</span> {outcome.timeToEffect}
                        </div>
                        <div>
                          <span className="text-gray-500">Duration:</span> {outcome.durationOfEffect}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Key Findings */}
              <div className="mb-6">
                <h3 className="font-semibold mb-3">Key Research Findings</h3>
                <ul className="space-y-2">
                  {selectedIntervention.keyFindings.map((finding, idx) => (
                    <li key={idx} className="flex gap-2 text-sm text-gray-300">
                      <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                      <span>{finding}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Practical Info */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-gray-800 rounded-lg p-3">
                  <div className="text-xs text-gray-500 mb-1">Safety Profile</div>
                  <div className={`inline-block px-2 py-1 rounded text-xs font-medium ${SAFETY_LABELS[selectedIntervention.safety].color} text-white`}>
                    {SAFETY_LABELS[selectedIntervention.safety].label}
                  </div>
                  <p className="text-xs text-gray-400 mt-1">
                    {SAFETY_LABELS[selectedIntervention.safety].desc}
                  </p>
                </div>
                
                <div className="bg-gray-800 rounded-lg p-3">
                  <div className="text-xs text-gray-500 mb-1">Accessibility</div>
                  <div className="text-sm font-medium capitalize">{selectedIntervention.accessibility}</div>
                  <div className="text-xs text-gray-400 mt-1">Cost: {selectedIntervention.cost}</div>
                </div>
              </div>

              {/* Citations */}
              <div>
                <h3 className="font-semibold mb-3 text-sm">Key Citations</h3>
                <div className="space-y-2">
                  {selectedIntervention.citations.slice(0, 3).map((citation, idx) => (
                    <div key={idx} className="text-xs text-gray-400 bg-gray-800 rounded p-2">
                      {citation}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
