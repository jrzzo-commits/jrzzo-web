// components/EffectsDisplay.tsx
'use client';

import { useMemo } from 'react';
import { BarChart, Bar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Activity, Brain, Heart, Zap } from 'lucide-react';
import { type Intervention, FREQUENCY_BANDS } from '../data/interventions';

interface EffectsDisplayProps {
  intervention: Intervention | null;
}

export default function EffectsDisplay({ intervention }: EffectsDisplayProps) {
  // Generate frequency band power data
  const frequencyData = useMemo(() => {
    if (!intervention) return [];
    
    return Object.entries(FREQUENCY_BANDS).map(([key, band]) => {
      const effect = intervention.frequencyEffects.find(e => e.band === key);
      
      let beforeValue = 50; // baseline
      let afterValue = 50;
      
      if (effect) {
        if (effect.change === 'increase') {
          afterValue = effect.magnitude === 'large' ? 85 :
                      effect.magnitude === 'medium' ? 70 :
                      60;
        } else if (effect.change === 'decrease') {
          afterValue = effect.magnitude === 'large' ? 20 :
                      effect.magnitude === 'medium' ? 35 :
                      40;
        } else {
          afterValue = 65; // modulate
        }
      }
      
      return {
        name: band.name,
        before: beforeValue,
        after: afterValue,
        range: band.range,
        color: band.color
      };
    });
  }, [intervention]);

  // Generate outcome metrics
  const outcomeMetrics = useMemo(() => {
    if (!intervention) return [];
    
    const effectSizeToPercentage = (d: number) => Math.min(Math.round(d * 25 + 50), 100);
    
    return [
      {
        category: 'Cognitive',
        before: 50,
        after: effectSizeToPercentage(intervention.evidence.effectSize),
        icon: Brain
      },
      {
        category: 'Emotional',
        before: 50,
        after: effectSizeToPercentage(intervention.evidence.effectSize * 0.9),
        icon: Heart
      },
      {
        category: 'Physiological',
        before: 50,
        after: effectSizeToPercentage(intervention.evidence.effectSize * 0.85),
        icon: Activity
      },
      {
        category: 'Energy',
        before: 50,
        after: effectSizeToPercentage(intervention.evidence.effectSize * 0.8),
        icon: Zap
      }
    ];
  }, [intervention]);

  // Generate radar chart data
  const radarData = useMemo(() => {
    if (!intervention) return [];
    
    return [
      {
        metric: 'Efficacy',
        value: intervention.evidence.effectSize * 30,
        fullMark: 100
      },
      {
        metric: 'Safety',
        value: intervention.safety === 'excellent' ? 95 :
               intervention.safety === 'good' ? 80 :
               intervention.safety === 'moderate' ? 60 : 40,
        fullMark: 100
      },
      {
        metric: 'Accessibility',
        value: intervention.accessibility === 'universal' ? 95 :
               intervention.accessibility === 'consumer' ? 70 :
               intervention.accessibility === 'clinical' ? 40 : 20,
        fullMark: 100
      },
      {
        metric: 'Speed',
        value: intervention.timeInvestment.includes('min') ? 90 :
               intervention.timeInvestment.includes('days') ? 60 :
               intervention.timeInvestment.includes('weeks') ? 40 : 20,
        fullMark: 100
      },
      {
        metric: 'Evidence',
        value: intervention.evidence.quality === 'gold' ? 95 :
               intervention.evidence.quality === 'silver' ? 75 :
               intervention.evidence.quality === 'bronze' ? 50 : 30,
        fullMark: 100
      }
    ];
  }, [intervention]);

  if (!intervention) {
    return (
      <div className="flex items-center justify-center h-full text-gray-500">
        <div className="text-center">
          <Brain className="w-16 h-16 mx-auto mb-4 opacity-20" />
          <p className="text-lg font-medium">No intervention selected</p>
          <p className="text-sm mt-2">Select an intervention to view detailed effects</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto p-6 bg-gray-900 text-white">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-2">Effects Analysis</h2>
        <p className="text-gray-400">
          {intervention.name} - Effect size: d = {intervention.evidence.effectSize.toFixed(2)}
        </p>
      </div>

      {/* Frequency Band Changes */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Activity className="w-5 h-5" />
          Brainwave Frequency Changes
        </h3>
        <div className="bg-gray-800 rounded-xl p-4">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={frequencyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" label={{ value: 'Power (%)', angle: -90, position: 'insideLeft', fill: '#9ca3af' }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }}
                labelStyle={{ color: '#fff' }}
              />
              <Legend />
              <Bar dataKey="before" fill="#6b7280" name="Baseline" radius={[4, 4, 0, 0]} />
              <Bar dataKey="after" fill="#3b82f6" name="After Intervention" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          
          {/* Frequency bands legend */}
          <div className="mt-4 grid grid-cols-2 md:grid-cols-5 gap-2">
            {frequencyData.map((band) => (
              <div key={band.name} className="text-xs">
                <div className="flex items-center gap-2 mb-1">
                  <div
                    className="w-3 h-3 rounded"
                    style={{ backgroundColor: band.color }}
                  />
                  <span className="font-medium">{band.name}</span>
                </div>
                <div className="text-gray-400">{band.range}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Outcome Metrics */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Outcome Improvements</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {outcomeMetrics.map((metric) => {
            const change = metric.after - metric.before;
            const percentChange = ((change / metric.before) * 100).toFixed(0);
            const Icon = metric.icon;
            
            return (
              <div key={metric.category} className="bg-gray-800 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Icon className="w-5 h-5 text-blue-400" />
                    <span className="font-medium">{metric.category}</span>
                  </div>
                  <div className="flex items-center gap-1 text-sm">
                    {change > 0 ? (
                      <TrendingUp className="w-4 h-4 text-green-400" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-400" />
                    )}
                    <span className={change > 0 ? 'text-green-400' : 'text-red-400'}>
                      {change > 0 ? '+' : ''}{percentChange}%
                    </span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-400">Baseline</span>
                      <span>{metric.before}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div
                        className="bg-gray-500 h-2 rounded-full transition-all"
                        style={{ width: `${metric.before}%` }}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-400">After Treatment</span>
                      <span>{metric.after}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div
                        className="bg-blue-500 h-2 rounded-full transition-all"
                        style={{ width: `${metric.after}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Intervention Profile Radar */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Intervention Profile</h3>
        <div className="bg-gray-800 rounded-xl p-4">
          <ResponsiveContainer width="100%" height={350}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="#374151" />
              <PolarAngleAxis dataKey="metric" stroke="#9ca3af" />
              <PolarRadiusAxis angle={90} domain={[0, 100]} stroke="#9ca3af" />
              <Radar
                name={intervention.name}
                dataKey="value"
                stroke="#3b82f6"
                fill="#3b82f6"
                fillOpacity={0.6}
              />
              <Tooltip
                contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }}
              />
            </RadarChart>
          </ResponsiveContainer>
          
          <div className="mt-4 text-xs text-gray-400 text-center">
            <p>Higher values indicate better performance in each dimension</p>
          </div>
        </div>
      </div>

      {/* Clinical Outcomes Summary */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Clinical Evidence Summary</h3>
        <div className="bg-gray-800 rounded-xl p-4 space-y-3">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <div className="text-gray-400 mb-1">Study Quality</div>
              <div className="font-medium capitalize">{intervention.evidence.quality} Standard</div>
            </div>
            <div>
              <div className="text-gray-400 mb-1">Replication Status</div>
              <div className="font-medium capitalize">{intervention.evidence.replicationStatus}</div>
            </div>
            <div>
              <div className="text-gray-400 mb-1">Total Studies</div>
              <div className="font-medium">{intervention.evidence.studyCount} published studies</div>
            </div>
            <div>
              <div className="text-gray-400 mb-1">Total Participants</div>
              <div className="font-medium">{intervention.evidence.participants.toLocaleString()} participants</div>
            </div>
          </div>
          
          <div className="pt-3 border-t border-gray-700">
            <div className="text-gray-400 text-xs mb-2">Time Investment</div>
            <div className="font-medium">{intervention.timeInvestment}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
