// components/BrainVisualization.tsx
'use client';

import { useRef, useMemo, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment } from '@react-three/drei';
import * as THREE from 'three';
import { FREQUENCY_BANDS } from '../data/interventions';

interface BrainProps {
  activeFrequencies: {
    band: keyof typeof FREQUENCY_BANDS;
    intensity: number; // 0-1
  }[];
  isAnimating: boolean;
}

function BrainMesh({ activeFrequencies, isAnimating }: BrainProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const materialRef = useRef<THREE.MeshPhysicalMaterial>(null);
  const particlesRef = useRef<THREE.Points>(null);
  
  // Create brain geometry - stylized brain shape
  const brainGeometry = useMemo(() => {
    const geometry = new THREE.SphereGeometry(2, 64, 64);
    const positions = geometry.attributes.position;
    
    // Deform sphere into brain-like shape
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i);
      const y = positions.getY(i);
      const z = positions.getZ(i);
      
      // Add hemispheric indentation
      const hemisphereFactor = Math.abs(x) < 0.2 ? 0.85 : 1.0;
      
      // Add wrinkles/gyri
      const noise = Math.sin(x * 5) * Math.cos(y * 4) * Math.sin(z * 6) * 0.15;
      
      const scale = hemisphereFactor + noise;
      positions.setXYZ(i, x * scale, y * scale, z * scale);
    }
    
    geometry.computeVertexNormals();
    return geometry;
  }, []);

  // Create particle system for "neural activity"
  const particles = useMemo(() => {
    const particleCount = 1000;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    
    for (let i = 0; i < particleCount; i++) {
      // Position particles in and around brain
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI;
      const radius = 2.2 + Math.random() * 0.5;
      
      positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = radius * Math.cos(phi);
      
      // Initial white color
      colors[i * 3] = 1;
      colors[i * 3 + 1] = 1;
      colors[i * 3 + 2] = 1;
    }
    
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    
    return geometry;
  }, []);

  // Calculate target color based on active frequencies
  const targetColor = useMemo(() => {
    if (activeFrequencies.length === 0) {
      return new THREE.Color(0x4488ff); // Default blue
    }
    
    // Blend colors based on intensity
    const color = new THREE.Color(0, 0, 0);
    let totalIntensity = 0;
    
    activeFrequencies.forEach(({ band, intensity }) => {
      const bandColor = new THREE.Color(FREQUENCY_BANDS[band].color);
      color.r += bandColor.r * intensity;
      color.g += bandColor.g * intensity;
      color.b += bandColor.b * intensity;
      totalIntensity += intensity;
    });
    
    if (totalIntensity > 0) {
      color.r /= totalIntensity;
      color.g /= totalIntensity;
      color.b /= totalIntensity;
    }
    
    return color;
  }, [activeFrequencies]);

  // Smooth color transition and rotation animation
  useFrame((state, delta) => {
    if (meshRef.current && materialRef.current) {
      // Smooth rotation
      if (isAnimating) {
        meshRef.current.rotation.y += delta * 0.3;
      }
      
      // Smooth color transition
      materialRef.current.color.lerp(targetColor, delta * 2);
      
      // Pulsing emissive effect based on activity
      const totalIntensity = activeFrequencies.reduce((sum, f) => sum + f.intensity, 0);
      const pulse = Math.sin(state.clock.elapsedTime * 2) * 0.1 + 0.1;
      materialRef.current.emissiveIntensity = totalIntensity > 0 ? pulse * totalIntensity : 0.05;
    }
    
    // Animate particles
    if (particlesRef.current && isAnimating) {
      particlesRef.current.rotation.y += delta * 0.1;
      
      const positions = particlesRef.current.geometry.attributes.position;
      const colors = particlesRef.current.geometry.attributes.color;
      
      for (let i = 0; i < positions.count; i++) {
        // Gentle floating motion
        const y = positions.getY(i);
        positions.setY(i, y + Math.sin(state.clock.elapsedTime + i) * delta * 0.1);
        
        // Color particles based on active frequencies
        if (activeFrequencies.length > 0) {
          colors.setXYZ(i, targetColor.r, targetColor.g, targetColor.b);
        } else {
          colors.setXYZ(i, 1, 1, 1);
        }
      }
      
      positions.needsUpdate = true;
      colors.needsUpdate = true;
    }
  });

  return (
    <>
      {/* Main brain mesh */}
      <mesh ref={meshRef} geometry={brainGeometry} castShadow receiveShadow>
        <meshPhysicalMaterial
          ref={materialRef}
          color={0x4488ff}
          emissive={0x223344}
          emissiveIntensity={0.05}
          transparent={true}
          opacity={0.9}
          roughness={0.3}
          metalness={0.2}
          clearcoat={0.3}
          clearcoatRoughness={0.2}
        />
      </mesh>
      
      {/* Neural activity particles */}
      <points ref={particlesRef} geometry={particles}>
        <pointsMaterial
          size={0.02}
          vertexColors={true}
          transparent={true}
          opacity={0.6}
          sizeAttenuation={true}
          blending={THREE.AdditiveBlending}
        />
      </points>
      
      {/* Subtle outer glow */}
      <mesh geometry={brainGeometry} scale={1.05}>
        <meshBasicMaterial
          color={targetColor}
          transparent={true}
          opacity={0.1}
          side={THREE.BackSide}
        />
      </mesh>
    </>
  );
}

export default function BrainVisualization({ activeFrequencies, isAnimating }: BrainProps) {
  return (
    <div className="w-full h-full min-h-[400px] relative">
      <Canvas shadows>
        <PerspectiveCamera makeDefault position={[0, 0, 8]} fov={50} />
        
        {/* Lighting setup */}
        <ambientLight intensity={0.4} />
        <directionalLight
          position={[10, 10, 5]}
          intensity={1}
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
        />
        <pointLight position={[-10, -10, -5]} intensity={0.5} color="#4488ff" />
        <spotLight
          position={[0, 10, 0]}
          intensity={0.5}
          angle={0.3}
          penumbra={1}
          color="#ffffff"
        />
        
        {/* Environment for reflections */}
        <Environment preset="city" />
        
        {/* Brain model */}
        <BrainMesh activeFrequencies={activeFrequencies} isAnimating={isAnimating} />
        
        {/* Controls */}
        <OrbitControls
          enablePan={false}
          enableZoom={true}
          minDistance={5}
          maxDistance={15}
          autoRotate={false}
        />
      </Canvas>
      
      {/* Frequency legend overlay */}
      <div className="absolute bottom-4 left-4 bg-gray-900/80 backdrop-blur-sm rounded-lg p-4 text-white text-sm">
        <div className="font-semibold mb-2">Active Frequencies</div>
        {activeFrequencies.length === 0 ? (
          <div className="text-gray-400 italic">Select an intervention to visualize</div>
        ) : (
          <div className="space-y-1">
            {activeFrequencies.map(({ band, intensity }) => (
              <div key={band} className="flex items-center gap-2">
                <div
                  className="w-4 h-4 rounded"
                  style={{ backgroundColor: FREQUENCY_BANDS[band].color }}
                />
                <span className="capitalize">{band}</span>
                <span className="text-gray-400">({FREQUENCY_BANDS[band].range})</span>
                <div className="ml-auto flex gap-0.5">
                  {[...Array(3)].map((_, i) => (
                    <div
                      key={i}
                      className={`w-1.5 h-3 rounded-sm ${
                        i < intensity * 3 ? 'bg-white' : 'bg-gray-600'
                      }`}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
