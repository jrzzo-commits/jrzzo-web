# 🚀 QUICK DEPLOYMENT GUIDE

## FASTEST PATH TO LIVE SITE (5 minutes)

### Step 1: Organize Files

Create this structure in your existing Next.js project:

```
your-project/
├── pages/
│   ├── _app.tsx                    ← Copy from: pages-_app.tsx
│   └── frequency-atlas.tsx         ← Copy from: pages-frequency-atlas.tsx
│
├── components/
│   ├── BrainVisualization.tsx      ← Copy from: components-BrainVisualization.tsx
│   ├── ControlPanel.tsx            ← Copy from: components-ControlPanel.tsx
│   └── EffectsDisplay.tsx          ← Copy from: components-EffectsDisplay.tsx
│
├── data/
│   └── interventions.ts            ← Copy from: data-interventions.ts
│
├── styles/
│   └── globals.css                 ← Copy from: styles-globals.css
│
└── Config files (if not already present):
    ├── package.json                ← Merge dependencies from frequency-atlas-package.json
    ├── tailwind.config.js          ← Copy or merge
    ├── tsconfig.json               ← Copy or merge
    ├── next.config.js              ← Copy or merge
    └── postcss.config.js           ← Copy
```

### Step 2: Install Dependencies

```bash
cd your-project

# Install new dependencies
npm install three @react-three/fiber @react-three/drei framer-motion recharts lucide-react

# Or if you prefer yarn
yarn add three @react-three/fiber @react-three/drei framer-motion recharts lucide-react
```

### Step 3: Test Locally

```bash
# Start development server
npm run dev

# Open in browser
# Navigate to: http://localhost:3000/frequency-atlas
```

### Step 4: Deploy to Vercel

**Option A: Via CLI (Recommended)**
```bash
# Install Vercel CLI (if not already installed)
npm install -g vercel

# Login
vercel login

# Deploy
vercel

# For production
vercel --prod
```

**Option B: Via GitHub**
1. Commit and push your changes to GitHub
2. Go to vercel.com
3. Click "New Project"
4. Import your repository
5. Vercel auto-detects Next.js - just click "Deploy"

---

## TROUBLESHOOTING

### "Module not found: three"
```bash
npm install three @react-three/fiber @react-three/drei
```

### "Tailwind classes not working"
1. Check `tailwind.config.js` includes paths:
```js
content: [
  './pages/**/*.{js,ts,jsx,tsx}',
  './components/**/*.{js,ts,jsx,tsx}',
]
```
2. Ensure `globals.css` is imported in `_app.tsx`
3. Restart dev server

### "Build fails on Vercel"
1. Check Node version (must be 18+)
2. Verify all dependencies in package.json
3. Check Vercel build logs for specific error

### "3D brain not rendering"
- WebGL must be enabled in browser
- Check browser console for errors
- Try different browser

---

## FILE MAPPING REFERENCE

| Source File (Downloaded)           | Destination in Your Project          |
|------------------------------------|--------------------------------------|
| frequency-atlas-package.json       | Merge into your package.json         |
| pages-frequency-atlas.tsx          | pages/frequency-atlas.tsx            |
| pages-_app.tsx                     | pages/_app.tsx                       |
| components-BrainVisualization.tsx  | components/BrainVisualization.tsx    |
| components-ControlPanel.tsx        | components/ControlPanel.tsx          |
| components-EffectsDisplay.tsx      | components/EffectsDisplay.tsx        |
| data-interventions.ts              | data/interventions.ts                |
| styles-globals.css                 | styles/globals.css                   |
| tailwind.config.js                 | tailwind.config.js                   |
| tsconfig.json                      | tsconfig.json                        |
| next.config.js                     | next.config.js                       |
| postcss.config.js                  | postcss.config.js                    |

---

## DEPENDENCIES TO MERGE INTO YOUR package.json

Add these to your existing package.json:

```json
{
  "dependencies": {
    "three": "^0.160.0",
    "@react-three/fiber": "^8.15.0",
    "@react-three/drei": "^9.92.0",
    "framer-motion": "^11.0.3",
    "lucide-react": "^0.263.1",
    "recharts": "^2.10.0"
  },
  "devDependencies": {
    "@types/three": "^0.160.0"
  }
}
```

Then run: `npm install`

---

## EXPECTED RESULT

After deployment, you should have:

✅ A working 3D brain visualization
✅ 10+ interventions to explore
✅ Interactive controls and smooth animations
✅ Comparison matrix functionality
✅ Combination protocols view
✅ Responsive on mobile and desktop

**Live URL:** `your-domain.vercel.app/frequency-atlas`

---

## NEXT STEPS

1. **Customize branding** - Update colors in tailwind.config.js
2. **Add analytics** - Google Analytics, Plausible, etc.
3. **Link from your research page** - Add navigation link
4. **Share on social media** - Post on Twitter/LinkedIn
5. **Gather feedback** - Iterate based on user testing

---

## SUPPORT

- 📖 Full documentation: See README.md
- 🐛 Issues: Check console errors first
- 💡 Feature requests: Document in TODO list
- 📧 Contact: [Your email/GitHub]

---

**Estimated deployment time: 5-10 minutes** ⚡

Good luck! 🚀
