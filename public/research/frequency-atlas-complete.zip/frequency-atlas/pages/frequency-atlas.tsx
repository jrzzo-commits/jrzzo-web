// pages/frequency-atlas.tsx
'use client';

import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Info, Download, Share2, BookOpen, Layers } from 'lucide-react';
import dynamic from 'next/dynamic';
import { INTERVENTIONS, FREQUENCY_BANDS, COMBINATION_PROTOCOLS, type Intervention } from '../data/interventions';
import ControlPanel from '../components/ControlPanel';
import EffectsDisplay from '../components/EffectsDisplay';

// Dynamically import BrainVisualization to avoid SSR issues with Three.js
const BrainVisualization = dynamic(() => import('../components/BrainVisualization'), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full flex items-center justify-center bg-gray-900">
      <div className="text-white">Loading 3D visualization...</div>
    </div>
  )
});

type ViewMode = 'explorer' | 'comparison' | 'combinations';

export default function FrequencyAtlasPage() {
  const [selectedIntervention, setSelectedIntervention] = useState<Intervention | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('explorer');
  const [compareInterventions, setCompareInterventions] = useState<Intervention[]>([]);
  const [isAnimating, setIsAnimating] = useState(true);

  // Calculate active frequencies for brain visualization
  const activeFrequencies = useMemo(() => {
    if (!selectedIntervention) return [];
    
    return selectedIntervention.frequencyEffects.map(effect => ({
      band: effect.band,
      intensity: effect.magnitude === 'large' ? 1 :
                effect.magnitude === 'medium' ? 0.66 :
                0.33
    }));
  }, [selectedIntervention]);

  const handleShare = () => {
    if (selectedIntervention) {
      const url = `${window.location.origin}/frequency-atlas?intervention=${selectedIntervention.id}`;
      navigator.clipboard.writeText(url);
      alert('Link copied to clipboard!');
    }
  };

  const handleDownloadReport = () => {
    if (selectedIntervention) {
      const report = `
FREQUENCY ATLAS REPORT
======================

Intervention: ${selectedIntervention.name}
Category: ${selectedIntervention.category}
Evidence Quality: ${selectedIntervention.evidence.quality}
Effect Size: d = ${selectedIntervention.evidence.effectSize}

Description:
${selectedIntervention.description}

Mechanism:
${selectedIntervention.mechanism}

Frequency Effects:
${selectedIntervention.frequencyEffects.map(e => 
  `- ${e.band.toUpperCase()}: ${e.change} (${e.magnitude} magnitude)`
).join('\n')}

Clinical Outcomes:
${selectedIntervention.clinicalOutcomes.map(o => 
  `- ${o.condition}: ${o.effectiveness} effectiveness (${o.timeToEffect})`
).join('\n')}

Key Findings:
${selectedIntervention.keyFindings.map((f, i) => `${i + 1}. ${f}`).join('\n')}

Citations:
${selectedIntervention.citations.join('\n')}

Generated from The Frequency Atlas - ${new Date().toLocaleDateString()}
      `.trim();
      
      const blob = new Blob([report], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `frequency-atlas-${selectedIntervention.id}.txt`;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Layers className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold">The Frequency Atlas</h1>
                <p className="text-xs text-gray-400">Interactive Map of Consciousness Modulation</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <button
                onClick={() => window.open('/research-paper', '_blank')}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
                title="Read Research Paper"
              >
                <BookOpen className="w-5 h-5" />
              </button>
              <button
                onClick={handleShare}
                disabled={!selectedIntervention}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors disabled:opacity-50"
                title="Share"
              >
                <Share2 className="w-5 h-5" />
              </button>
              <button
                onClick={handleDownloadReport}
                disabled={!selectedIntervention}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors disabled:opacity-50"
                title="Download Report"
              >
                <Download className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* View Mode Selector */}
      <div className="border-b border-gray-800 bg-gray-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-1 py-2">
            <button
              onClick={() => setViewMode('explorer')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                viewMode === 'explorer'
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              Interactive Explorer
            </button>
            <button
              onClick={() => setViewMode('comparison')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                viewMode === 'comparison'
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              Compare Interventions
            </button>
            <button
              onClick={() => setViewMode('combinations')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                viewMode === 'combinations'
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              Combination Protocols
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {viewMode === 'explorer' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-12rem)]">
            {/* Control Panel */}
            <div className="lg:col-span-1 bg-gray-900 rounded-xl shadow-2xl overflow-hidden border border-gray-800">
              <ControlPanel
                selectedIntervention={selectedIntervention}
                onSelectIntervention={setSelectedIntervention}
              />
            </div>

            {/* Brain Visualization */}
            <div className="lg:col-span-1 bg-gray-900 rounded-xl shadow-2xl overflow-hidden border border-gray-800 relative">
              <BrainVisualization
                activeFrequencies={activeFrequencies}
                isAnimating={isAnimating}
              />
              
              {/* Animation toggle */}
              <button
                onClick={() => setIsAnimating(!isAnimating)}
                className="absolute top-4 right-4 px-3 py-1.5 bg-gray-800/80 hover:bg-gray-700/80 backdrop-blur-sm rounded-lg text-xs font-medium transition-colors"
              >
                {isAnimating ? '⏸ Pause' : '▶ Play'}
              </button>
            </div>

            {/* Effects Display */}
            <div className="lg:col-span-1 bg-gray-900 rounded-xl shadow-2xl overflow-hidden border border-gray-800">
              <EffectsDisplay intervention={selectedIntervention} />
            </div>
          </div>
        )}

        {viewMode === 'comparison' && (
          <ComparisonView
            interventions={INTERVENTIONS}
            selectedForComparison={compareInterventions}
            onToggleComparison={(intervention) => {
              setCompareInterventions(prev =>
                prev.find(i => i.id === intervention.id)
                  ? prev.filter(i => i.id !== intervention.id)
                  : [...prev, intervention].slice(0, 4) // Max 4 interventions
              );
            }}
          />
        )}

        {viewMode === 'combinations' && (
          <CombinationsView protocols={COMBINATION_PROTOCOLS} />
        )}
      </main>

      {/* Info Banner */}
      <div className="fixed bottom-4 right-4 max-w-sm bg-blue-600/10 border border-blue-500/30 backdrop-blur-sm rounded-lg p-4 shadow-lg">
        <div className="flex gap-3">
          <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="font-medium text-blue-100 mb-1">Research-Based</p>
            <p className="text-blue-200/80 text-xs">
              All visualizations based on 150+ peer-reviewed studies. Click interventions to explore the science.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// Comparison View Component
function ComparisonView({
  interventions,
  selectedForComparison,
  onToggleComparison
}: {
  interventions: Intervention[];
  selectedForComparison: Intervention[];
  onToggleComparison: (intervention: Intervention) => void;
}) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Compare Interventions</h2>
        <p className="text-gray-400">Select up to 4 interventions to compare side-by-side</p>
      </div>

      {/* Selection Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {interventions.map(intervention => (
          <button
            key={intervention.id}
            onClick={() => onToggleComparison(intervention)}
            className={`p-4 rounded-xl border-2 transition-all text-left ${
              selectedForComparison.find(i => i.id === intervention.id)
                ? 'border-blue-500 bg-blue-600/20'
                : 'border-gray-800 bg-gray-900 hover:border-gray-700'
            }`}
          >
            <h3 className="font-semibold text-sm mb-2">{intervention.name}</h3>
            <div className="text-xs text-gray-400">{intervention.category}</div>
          </button>
        ))}
      </div>

      {/* Comparison Matrix */}
      {selectedForComparison.length > 1 && (
        <div className="bg-gray-900 rounded-xl p-6 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left py-3 px-4 font-semibold">Metric</th>
                {selectedForComparison.map(intervention => (
                  <th key={intervention.id} className="text-left py-3 px-4 font-semibold">
                    {intervention.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-800">
                <td className="py-3 px-4 text-gray-400">Evidence Quality</td>
                {selectedForComparison.map(intervention => (
                  <td key={intervention.id} className="py-3 px-4 capitalize">
                    {intervention.evidence.quality}
                  </td>
                ))}
              </tr>
              <tr className="border-b border-gray-800">
                <td className="py-3 px-4 text-gray-400">Effect Size</td>
                {selectedForComparison.map(intervention => (
                  <td key={intervention.id} className="py-3 px-4">
                    d = {intervention.evidence.effectSize}
                  </td>
                ))}
              </tr>
              <tr className="border-b border-gray-800">
                <td className="py-3 px-4 text-gray-400">Safety</td>
                {selectedForComparison.map(intervention => (
                  <td key={intervention.id} className="py-3 px-4 capitalize">
                    {intervention.safety}
                  </td>
                ))}
              </tr>
              <tr className="border-b border-gray-800">
                <td className="py-3 px-4 text-gray-400">Cost</td>
                {selectedForComparison.map(intervention => (
                  <td key={intervention.id} className="py-3 px-4">
                    {intervention.cost}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 text-gray-400">Accessibility</td>
                {selectedForComparison.map(intervention => (
                  <td key={intervention.id} className="py-3 px-4 capitalize">
                    {intervention.accessibility}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// Combinations View Component
function CombinationsView({ protocols }: { protocols: typeof COMBINATION_PROTOCOLS }) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Combination Protocols</h2>
        <p className="text-gray-400">
          Synergistic intervention combinations that may produce enhanced effects
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {protocols.map((protocol, idx) => (
          <motion.div
            key={protocol.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-gray-900 rounded-xl p-6 border border-gray-800"
          >
            <h3 className="text-xl font-bold mb-2">{protocol.name}</h3>
            <p className="text-gray-400 text-sm mb-4">{protocol.description}</p>
            
            <div className="mb-4">
              <div className="text-xs text-gray-500 mb-2">PROTOCOL</div>
              <div className="bg-gray-800 rounded-lg p-3 text-sm font-mono">
                {protocol.protocol}
              </div>
            </div>
            
            <div className="mb-4">
              <div className="text-xs text-gray-500 mb-2">PREDICTED EFFECT</div>
              <p className="text-sm">{protocol.predictedEffect}</p>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="text-xs text-gray-500">
                {protocol.interventions.length} interventions combined
              </div>
              <div className="px-3 py-1 bg-blue-600/20 text-blue-400 rounded-full text-xs font-medium">
                {protocol.synergy}x synergy
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="bg-yellow-600/10 border border-yellow-500/30 rounded-lg p-4">
        <div className="flex gap-3">
          <Info className="w-5 h-5 text-yellow-400 flex-shrink-0" />
          <div className="text-sm">
            <p className="font-medium text-yellow-100 mb-1">Research Note</p>
            <p className="text-yellow-200/80">
              Combination protocols are based on mechanistic reasoning but require rigorous clinical trials for validation.
              Consult healthcare providers before combining interventions.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
